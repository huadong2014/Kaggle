import pandas as pd

#combined transactions v1 & v2
transaction = pd.read_csv('transactions.csv')
transaction_grouped = transaction.groupby(transaction['msno'])

# #201702, official train
# train = pd.read_csv('train.csv')
# train_grouped = train.groupby(train["is_churn"])
#
# #201702, our train
# mytrain = pd.read_csv('sample_user_label201702/train2.csv')
# mytrain_grouped = mytrain.groupby(mytrain["is_churn"])
#
# i = 0
# for msno in set(train_grouped.get_group(1)['msno']) - set(mytrain_grouped.get_group(1)['msno']):
#     transactions = transaction_grouped.get_group(msno).sort_values(by=['transaction_date','membership_expire_date'])
#     transactions.to_csv('train-1-201702(real-our).csv', mode="a")
#     i = i+1
#     if i>100:
#         break
#
# i = 0
# for msno in set(mytrain_grouped.get_group(1)['msno']) - set(train_grouped.get_group(1)['msno']):
#     transactions = transaction_grouped.get_group(msno).sort_values(by=['transaction_date','membership_expire_date'])
#     transactions.to_csv('train-1-201702(our-real).csv', mode="a")
#     i = i+1
#     if i>100:
#         break
#
# i = 0
# for msno in set(train_grouped.get_group(1)['msno']) & set(mytrain_grouped.get_group(1)['msno']):
#     transactions = transaction_grouped.get_group(msno).sort_values(by=['transaction_date','membership_expire_date'])
#     transactions.to_csv('train-1-201702(our&real).csv.csv', mode="a")
#     i = i+1
#     if i>100:
#         break


#201703, official train
train = pd.read_csv('train_v2.csv')
train_grouped = train.groupby(train["is_churn"])

#201703, our train
mytrain = pd.read_csv('sample_user_label201703/train3.csv')
mytrain_grouped = mytrain.groupby(mytrain["is_churn"])

i = 0
for msno in set(train_grouped.get_group(1)['msno']) - set(mytrain_grouped.get_group(1)['msno']):
    transactions = transaction_grouped.get_group(msno).sort_values(by=['transaction_date','membership_expire_date'])
    transactions.to_csv('train-1-201703(real-our).csv', mode="a")
    i = i+1
    if i>100:
        break

i = 0
for msno in set(mytrain_grouped.get_group(1)['msno']) - set(train_grouped.get_group(1)['msno']):
    transactions = transaction_grouped.get_group(msno).sort_values(by=['transaction_date','membership_expire_date'])
    transactions.to_csv('train-1-201703(our-real).csv', mode="a")
    i = i+1
    if i>100:
        break

i = 0
for msno in set(train_grouped.get_group(1)['msno']) & set(mytrain_grouped.get_group(1)['msno']):
    transactions = transaction_grouped.get_group(msno).sort_values(by=['transaction_date','membership_expire_date'])
    transactions.to_csv('train-1-201703(our&real).csv.csv', mode="a")
    i = i+1
    if i>100:
        break
